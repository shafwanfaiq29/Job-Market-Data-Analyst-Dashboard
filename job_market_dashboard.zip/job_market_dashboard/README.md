# Job Market Data Analyst Dashboard

Dashboard ini dibuat untuk menganalisis job market bidang Data Analyst dan Data Science. Analisis yang ditampilkan meliputi role yang paling banyak muncul, perbandingan salary, pengaruh experience level, remote work, negara dengan kompensasi tertinggi, opportunity score, dan skill yang paling dicari perusahaan.

## Struktur project

```text
job_market_dashboard/
├── app.py
├── requirements.txt
├── README.md
└── data/
    └── ds_salaries.csv
```

## Dataset

Dashboard memakai dua dataset:

1. `ds_salaries.csv`  
   Dipakai untuk analisis salary, role, experience level, remote work, negara perusahaan, dan opportunity score.

2. `lukebarousse/data_jobs` dari Hugging Face  
   Dipakai untuk analisis skill yang dicari perusahaan. Data ini dimuat otomatis saat bagian analisis skill diaktifkan.

## Cara menjalankan

Buka terminal di folder project, lalu jalankan:

```bash
pip install -r requirements.txt
streamlit run app.py
```

Jika ingin upload ke GitHub, gunakan alur berikut:

```bash
git init
git add .
git commit -m "add job market dashboard"
git branch -M main
git remote add origin https://github.com/username/nama-repo.git
git push -u origin main
```

## Catatan analisis

- Median salary digunakan sebagai acuan utama karena data gaji dapat memiliki outlier.
- Analisis negara perlu dibaca hati-hati karena jumlah data tiap negara tidak seimbang.
- Analisis skill salary dari dataset Hugging Face hanya memakai job posting yang memiliki informasi salary, sehingga hasilnya lebih tepat disebut sebagai indikasi pola.
- Opportunity Score bukan ranking mutlak, tetapi ringkasan sederhana dari demand, salary, dan peluang fully remote.
