from pathlib import Path
import ast

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
from datasets import load_dataset


# ============================================================
# Konfigurasi halaman
# ============================================================

st.set_page_config(
    page_title="Job Market Data Analyst Dashboard",
    page_icon="📊",
    layout="wide"
)

BASE_DIR = Path(__file__).resolve().parent
SALARY_PATH = BASE_DIR / "data" / "ds_salaries.csv"


# ============================================================
# Fungsi bantu
# ============================================================

def format_usd(value):
    if pd.isna(value):
        return "-"
    return f"${value:,.0f}"


def group_role(title):
    title = str(title).lower()

    if "data analyst" in title or "product data analyst" in title:
        return "Data Analyst"
    if "data scientist" in title or "research scientist" in title:
        return "Data Scientist"
    if "data engineer" in title or "big data engineer" in title or "etl" in title:
        return "Data Engineer"
    if "machine learning" in title or "ml engineer" in title or "ai scientist" in title:
        return "Machine Learning / AI"
    if "analytics" in title or "bi" in title or "business analyst" in title:
        return "Analytics / BI"
    if "data architect" in title:
        return "Data Architect"
    if "data science" in title:
        return "Data Science Management"
    return "Other Data Role"


COUNTRY_MAP = {
    "US": "United States", "GB": "United Kingdom", "CA": "Canada", "DE": "Germany",
    "IN": "India", "FR": "France", "ES": "Spain", "GR": "Greece", "JP": "Japan",
    "NL": "Netherlands", "AT": "Austria", "PT": "Portugal", "PL": "Poland",
    "PK": "Pakistan", "BR": "Brazil", "AU": "Australia", "TR": "Turkey", "DK": "Denmark",
    "MX": "Mexico", "NG": "Nigeria", "CN": "China", "RU": "Russia", "IT": "Italy",
    "CH": "Switzerland", "AE": "United Arab Emirates", "SG": "Singapore", "BE": "Belgium",
    "LU": "Luxembourg", "SI": "Slovenia", "RO": "Romania", "VN": "Vietnam", "CL": "Chile",
    "HU": "Hungary", "EE": "Estonia", "CZ": "Czech Republic", "DZ": "Algeria", "MY": "Malaysia",
    "HN": "Honduras", "NZ": "New Zealand", "IE": "Ireland", "MT": "Malta", "UA": "Ukraine",
    "IQ": "Iraq", "IR": "Iran", "CO": "Colombia", "KE": "Kenya", "MD": "Moldova",
    "AS": "American Samoa"
}


@st.cache_data(show_spinner=False)
def load_salary_data(path):
    df = pd.read_csv(path)

    if "Unnamed: 0" in df.columns:
        df = df.drop(columns=["Unnamed: 0"])

    experience_map = {
        "EN": "Entry Level",
        "MI": "Mid Level",
        "SE": "Senior Level",
        "EX": "Executive Level"
    }

    employment_map = {
        "FT": "Full-time",
        "PT": "Part-time",
        "CT": "Contract",
        "FL": "Freelance"
    }

    remote_map = {
        0: "On-site",
        50: "Hybrid",
        100: "Fully Remote"
    }

    company_size_map = {
        "S": "Small",
        "M": "Medium",
        "L": "Large"
    }

    df["experience_label"] = df["experience_level"].map(experience_map)
    df["employment_label"] = df["employment_type"].map(employment_map)
    df["remote_label"] = df["remote_ratio"].map(remote_map)
    df["company_size_label"] = df["company_size"].map(company_size_map)
    df["role_group"] = df["job_title"].apply(group_role)
    df["company_country"] = df["company_location"].map(COUNTRY_MAP).fillna(df["company_location"])
    df["employee_country"] = df["employee_residence"].map(COUNTRY_MAP).fillna(df["employee_residence"])

    return df


def clean_skill_list(skills):
    if skills is None:
        return []

    if isinstance(skills, list):
        skill_list = skills
    elif isinstance(skills, np.ndarray):
        skill_list = skills.tolist()
    elif isinstance(skills, str):
        try:
            skill_list = ast.literal_eval(skills)
        except Exception:
            skill_list = [skills]
    else:
        try:
            if pd.isna(skills):
                return []
        except Exception:
            return []
        return []

    cleaned = []
    for skill in skill_list:
        skill = str(skill).strip().lower()
        if skill and skill not in cleaned:
            cleaned.append(skill)

    return cleaned


@st.cache_data(show_spinner="Mengambil dan menyiapkan data skill dari Hugging Face...")
def build_skill_tables():
    ds = load_dataset("lukebarousse/data_jobs")
    df_jobs = ds["train"].to_pandas()

    df_jobs["skills_clean"] = df_jobs["job_skills"].apply(clean_skill_list)
    df_with_skills = df_jobs[df_jobs["skills_clean"].apply(len) > 0].copy()
    df_with_skills["work_type"] = np.where(
        df_with_skills["job_work_from_home"],
        "Work From Home",
        "On-site / Not Mentioned"
    )

    df_skills = df_with_skills.explode("skills_clean").rename(columns={"skills_clean": "skill"})

    total_jobs_with_skills = len(df_with_skills)

    # Skill paling umum
    skill_overall = (
        df_skills.groupby("skill")
        .size()
        .reset_index(name="total_mentions")
        .sort_values("total_mentions", ascending=False)
    )
    skill_overall["percentage"] = (skill_overall["total_mentions"] / total_jobs_with_skills * 100).round(2)

    # Skill Data Analyst
    da_jobs = df_with_skills[df_with_skills["job_title_short"] == "Data Analyst"].copy()
    da_skills = df_skills[df_skills["job_title_short"] == "Data Analyst"].copy()
    total_da_jobs = len(da_jobs)

    skill_data_analyst = (
        da_skills.groupby("skill")
        .size()
        .reset_index(name="total_mentions")
        .sort_values("total_mentions", ascending=False)
    )
    skill_data_analyst["percentage"] = (skill_data_analyst["total_mentions"] / total_da_jobs * 100).round(2)

    # Perbandingan skill antar role
    roles_to_compare = ["Data Analyst", "Data Scientist", "Data Engineer", "Machine Learning Engineer"]
    main_skills = [
        "sql", "python", "excel", "tableau", "power bi", "r", "aws", "azure",
        "spark", "hadoop", "airflow", "tensorflow", "pytorch"
    ]

    df_roles = df_with_skills[df_with_skills["job_title_short"].isin(roles_to_compare)]
    df_role_skills = df_skills[df_skills["job_title_short"].isin(roles_to_compare)]

    role_totals = df_roles.groupby("job_title_short").size().reset_index(name="total_jobs")
    skill_by_role = (
        df_role_skills.groupby(["job_title_short", "skill"])
        .size()
        .reset_index(name="total_mentions")
        .merge(role_totals, on="job_title_short", how="left")
    )
    skill_by_role["percentage"] = skill_by_role["total_mentions"] / skill_by_role["total_jobs"] * 100

    skill_role_matrix = (
        skill_by_role.pivot(index="skill", columns="job_title_short", values="percentage")
        .reindex(main_skills)
        .reindex(columns=roles_to_compare)
        .fillna(0)
        .round(2)
    )

    # Remote skill
    remote_jobs = df_with_skills[df_with_skills["job_work_from_home"]]
    non_remote_jobs = df_with_skills[~df_with_skills["job_work_from_home"]]
    remote_skills = df_skills[df_skills["job_work_from_home"]]
    non_remote_skills = df_skills[~df_skills["job_work_from_home"]]

    skill_remote_top = (
        remote_skills.groupby("skill")
        .size()
        .reset_index(name="total_mentions")
        .sort_values("total_mentions", ascending=False)
    )
    skill_remote_top["percentage"] = (skill_remote_top["total_mentions"] / len(remote_jobs) * 100).round(2)

    remote_pct = remote_skills.groupby("skill").size().reset_index(name="remote_mentions")
    remote_pct["remote_percentage"] = remote_pct["remote_mentions"] / len(remote_jobs) * 100

    non_remote_pct = non_remote_skills.groupby("skill").size().reset_index(name="non_remote_mentions")
    non_remote_pct["non_remote_percentage"] = non_remote_pct["non_remote_mentions"] / len(non_remote_jobs) * 100

    remote_compare = remote_pct.merge(non_remote_pct, on="skill", how="outer").fillna(0)
    remote_compare["gap_remote_vs_non_remote"] = remote_compare["remote_percentage"] - remote_compare["non_remote_percentage"]

    selected_remote_skills = [
        "sql", "python", "excel", "tableau", "power bi", "r", "aws", "azure",
        "spark", "snowflake", "databricks", "docker", "kubernetes", "tensorflow", "pytorch"
    ]

    remote_compare = (
        remote_compare[remote_compare["skill"].isin(selected_remote_skills)]
        .sort_values("gap_remote_vs_non_remote", ascending=False)
        .round(2)
    )

    # Rekomendasi skill Data Analyst berdasarkan demand dan salary
    salary_skill_data = df_skills[df_skills["salary_year_avg"].notna()].copy()
    da_salary_skill_data = salary_skill_data[salary_skill_data["job_title_short"] == "Data Analyst"].copy()

    da_skill_demand = (
        da_skills.groupby("skill")
        .size()
        .reset_index(name="total_mentions")
    )
    da_skill_demand["demand_percentage"] = da_skill_demand["total_mentions"] / total_da_jobs * 100

    da_skill_salary = (
        da_salary_skill_data.groupby("skill")
        .agg(
            salary_mentions=("skill", "count"),
            median_salary=("salary_year_avg", "median")
        )
        .reset_index()
    )

    skill_recommendation = da_skill_demand.merge(da_skill_salary, on="skill", how="inner")
    skill_recommendation = skill_recommendation[skill_recommendation["salary_mentions"] >= 30].copy()

    def learning_priority(row):
        skill = row["skill"]
        wajib = ["sql", "excel", "python"]
        bi_tools = ["tableau", "power bi", "looker", "qlik"]
        premium = [
            "snowflake", "spark", "hadoop", "gcp", "aws", "azure",
            "databricks", "airflow", "kafka", "bigquery"
        ]

        if skill in wajib:
            return "Wajib dipelajari"
        if skill in bi_tools:
            return "BI & reporting tools"
        if skill in premium:
            return "Skill premium"
        if row["demand_percentage"] >= 5:
            return "Skill pendukung utama"
        return "Skill tambahan"

    skill_recommendation["learning_priority"] = skill_recommendation.apply(learning_priority, axis=1)
    skill_recommendation["demand_percentage"] = skill_recommendation["demand_percentage"].round(2)
    skill_recommendation["median_salary"] = skill_recommendation["median_salary"].round(0)

    priority_order = [
        "Wajib dipelajari",
        "BI & reporting tools",
        "Skill premium",
        "Skill pendukung utama",
        "Skill tambahan"
    ]

    skill_recommendation["learning_priority"] = pd.Categorical(
        skill_recommendation["learning_priority"],
        categories=priority_order,
        ordered=True
    )

    skill_recommendation = skill_recommendation.sort_values(
        ["learning_priority", "demand_percentage", "median_salary"],
        ascending=[True, False, False]
    )

    work_type_summary = (
        df_with_skills.groupby("work_type")
        .size()
        .reset_index(name="total_jobs")
        .sort_values("total_jobs", ascending=False)
    )
    work_type_summary["percentage"] = (work_type_summary["total_jobs"] / len(df_with_skills) * 100).round(2)

    return {
        "skill_overall": skill_overall,
        "skill_data_analyst": skill_data_analyst,
        "skill_role_matrix": skill_role_matrix,
        "skill_remote_top": skill_remote_top,
        "remote_compare": remote_compare,
        "skill_recommendation": skill_recommendation,
        "work_type_summary": work_type_summary,
        "total_jobs_with_skills": total_jobs_with_skills,
        "total_da_jobs": total_da_jobs,
    }


def make_bar(df, x, y, title, orientation="h", text=None):
    fig = px.bar(df, x=x, y=y, orientation=orientation, text=text, title=title)
    fig.update_layout(title_x=0.02, height=430)
    fig.update_traces(textposition="outside")
    return fig


# ============================================================
# Load data salary
# ============================================================

if not SALARY_PATH.exists():
    st.error("File data/ds_salaries.csv belum ditemukan. Simpan file dataset salary ke folder data terlebih dahulu.")
    st.stop()

salary_data = load_salary_data(SALARY_PATH)


# ============================================================
# Header
# ============================================================

st.title("Dashboard Job Market Data Analyst & Data Science")
st.caption("Analisis salary, peluang remote, lokasi perusahaan, opportunity score, dan skill yang dicari perusahaan.")

with st.expander("Tentang dashboard ini", expanded=False):
    st.write(
        "Dashboard ini memakai dua sumber data. Dataset salary digunakan untuk melihat gaji, role, "
        "experience level, remote work, negara perusahaan, dan opportunity score. Dataset job posting "
        "dari Hugging Face digunakan untuk melihat skill yang paling banyak dicari perusahaan."
    )


# ============================================================
# Sidebar filter
# ============================================================

st.sidebar.header("Filter data salary")

all_years = sorted(salary_data["work_year"].unique().tolist())
selected_years = st.sidebar.multiselect("Tahun", all_years, default=all_years)

all_roles = sorted(salary_data["role_group"].unique().tolist())
selected_roles = st.sidebar.multiselect("Role group", all_roles, default=all_roles)

all_experience = ["Entry Level", "Mid Level", "Senior Level", "Executive Level"]
selected_experience = st.sidebar.multiselect("Experience level", all_experience, default=all_experience)

load_skill_section = st.sidebar.checkbox("Muat analisis skill dari Hugging Face", value=True)
st.sidebar.caption("Analisis skill butuh internet dan bisa agak lama saat pertama kali dijalankan.")

filtered_salary = salary_data[
    salary_data["work_year"].isin(selected_years)
    & salary_data["role_group"].isin(selected_roles)
    & salary_data["experience_label"].isin(selected_experience)
].copy()

if filtered_salary.empty:
    st.warning("Tidak ada data yang sesuai dengan filter.")
    st.stop()


# ============================================================
# Metric ringkas
# ============================================================

role_counts = filtered_salary["role_group"].value_counts()
top_role_name = role_counts.index[0]
top_role_total = role_counts.iloc[0]
median_salary_all = filtered_salary["salary_in_usd"].median()
fully_remote_pct = (filtered_salary["remote_label"].eq("Fully Remote").mean() * 100)
top_country = filtered_salary["company_country"].value_counts().index[0]

col1, col2, col3, col4 = st.columns(4)
col1.metric("Total data salary", f"{len(filtered_salary):,}")
col2.metric("Median salary", format_usd(median_salary_all))
col3.metric("Fully remote", f"{fully_remote_pct:.1f}%")
col4.metric("Role paling banyak", f"{top_role_name}", f"{top_role_total} data")


# ============================================================
# Tabs
# ============================================================

tab_overview, tab_salary, tab_country, tab_skill, tab_opportunity = st.tabs([
    "Overview",
    "Salary & career",
    "Negara",
    "Skill",
    "Opportunity score"
])


# ============================================================
# Overview
# ============================================================

with tab_overview:
    st.subheader("Gambaran besar")
    st.write(
        "Bagian ini menunjukkan role yang paling banyak muncul dan posisi Data Analyst dibanding role lain. "
        "Gunakan bagian ini sebagai pembuka saat presentasi."
    )

    role_group_summary = (
        filtered_salary["role_group"].value_counts()
        .reset_index()
        .rename(columns={"role_group": "role_group", "count": "total"})
    )

    if "count" not in role_group_summary.columns:
        role_group_summary.columns = ["role_group", "total"]

    role_group_summary["percentage"] = (role_group_summary["total"] / len(filtered_salary) * 100).round(2)

    top_titles = (
        filtered_salary["job_title"].value_counts()
        .head(15)
        .reset_index()
    )
    top_titles.columns = ["job_title", "total"]

    left, right = st.columns(2)

    with left:
        fig = px.bar(
            role_group_summary.sort_values("total"),
            x="total",
            y="role_group",
            orientation="h",
            text="total",
            title="Role group paling banyak muncul"
        )
        fig.update_layout(height=430, title_x=0.02, yaxis_title="Role group", xaxis_title="Jumlah data")
        fig.update_traces(textposition="outside")
        st.plotly_chart(fig, use_container_width=True)

    with right:
        fig = px.bar(
            top_titles.sort_values("total"),
            x="total",
            y="job_title",
            orientation="h",
            text="total",
            title="Top job title paling banyak muncul"
        )
        fig.update_layout(height=430, title_x=0.02, yaxis_title="Job title", xaxis_title="Jumlah data")
        fig.update_traces(textposition="outside")
        st.plotly_chart(fig, use_container_width=True)

    st.info(
        "Insight utama: Data Scientist, Data Engineer, dan Data Analyst adalah role yang paling dominan. "
        "Data Analyst tetap kuat sebagai fokus project karena jumlah datanya cukup besar dan relevan untuk jalur awal karier data."
    )


# ============================================================
# Salary & career
# ============================================================

with tab_salary:
    st.subheader("Salary berdasarkan role, experience, dan tipe kerja")

    salary_by_role = (
        filtered_salary.groupby("role_group")
        .agg(
            total_data=("salary_in_usd", "count"),
            median_salary=("salary_in_usd", "median"),
            average_salary=("salary_in_usd", "mean"),
            min_salary=("salary_in_usd", "min"),
            max_salary=("salary_in_usd", "max")
        )
        .reset_index()
        .sort_values("median_salary", ascending=False)
    )

    salary_by_role_display = salary_by_role.copy()
    salary_by_role_display["median_salary"] = salary_by_role_display["median_salary"].round(0)
    salary_by_role_display["average_salary"] = salary_by_role_display["average_salary"].round(0)

    col_a, col_b = st.columns(2)

    with col_a:
        fig = px.bar(
            salary_by_role.sort_values("median_salary"),
            x="median_salary",
            y="role_group",
            orientation="h",
            text="median_salary",
            title="Median salary berdasarkan role"
        )
        fig.update_layout(height=430, title_x=0.02, xaxis_title="Median salary USD", yaxis_title="Role group")
        fig.update_traces(texttemplate="$%{text:,.0f}", textposition="outside")
        st.plotly_chart(fig, use_container_width=True)

    with col_b:
        fig = px.box(
            filtered_salary,
            x="salary_in_usd",
            y="role_group",
            title="Distribusi salary berdasarkan role"
        )
        fig.update_layout(height=430, title_x=0.02, xaxis_title="Salary USD", yaxis_title="Role group")
        st.plotly_chart(fig, use_container_width=True)

    st.dataframe(salary_by_role_display, use_container_width=True)

    experience_order = ["Entry Level", "Mid Level", "Senior Level", "Executive Level"]
    remote_order = ["On-site", "Hybrid", "Fully Remote"]

    salary_by_exp = (
        filtered_salary.groupby("experience_label")
        .agg(total_data=("salary_in_usd", "count"), median_salary=("salary_in_usd", "median"))
        .reindex(experience_order)
        .reset_index()
    )

    salary_by_remote = (
        filtered_salary.groupby("remote_label")
        .agg(total_data=("salary_in_usd", "count"), median_salary=("salary_in_usd", "median"))
        .reindex(remote_order)
        .reset_index()
    )

    left, right = st.columns(2)

    with left:
        fig = px.bar(
            salary_by_exp.dropna(),
            x="experience_label",
            y="median_salary",
            text="median_salary",
            title="Median salary berdasarkan experience level"
        )
        fig.update_layout(height=420, title_x=0.02, xaxis_title="Experience level", yaxis_title="Median salary USD")
        fig.update_traces(texttemplate="$%{text:,.0f}", textposition="outside")
        st.plotly_chart(fig, use_container_width=True)

    with right:
        fig = px.bar(
            salary_by_remote.dropna(),
            x="remote_label",
            y="median_salary",
            text="median_salary",
            title="Median salary berdasarkan tipe kerja"
        )
        fig.update_layout(height=420, title_x=0.02, xaxis_title="Tipe kerja", yaxis_title="Median salary USD")
        fig.update_traces(texttemplate="$%{text:,.0f}", textposition="outside")
        st.plotly_chart(fig, use_container_width=True)

    st.success(
        "Insight utama: Experience level adalah faktor yang paling jelas memengaruhi salary. "
        "Fully remote juga terlihat memiliki median salary yang lebih tinggi, tetapi tetap perlu dibaca bersama experience level."
    )


# ============================================================
# Negara
# ============================================================

with tab_country:
    st.subheader("Negara perusahaan dan kompensasi")
    st.write(
        "Analisis ini memakai lokasi perusahaan, bukan tempat tinggal pekerja. Negara dengan data terlalu sedikit bisa membuat median salary terlihat bias."
    )

    country_count = (
        filtered_salary.groupby("company_country")
        .size()
        .reset_index(name="total_data")
        .sort_values("total_data", ascending=False)
    )

    country_salary = (
        filtered_salary.groupby("company_country")
        .agg(
            total_data=("salary_in_usd", "count"),
            median_salary=("salary_in_usd", "median"),
            average_salary=("salary_in_usd", "mean")
        )
        .reset_index()
    )

    min_country_data = st.slider("Minimal jumlah data per negara", min_value=1, max_value=20, value=5)
    country_salary_filtered = country_salary[country_salary["total_data"] >= min_country_data].sort_values("median_salary", ascending=False)

    left, right = st.columns(2)

    with left:
        fig = px.bar(
            country_salary_filtered.head(10).sort_values("median_salary"),
            x="median_salary",
            y="company_country",
            orientation="h",
            text="median_salary",
            title="Negara dengan median salary tertinggi"
        )
        fig.update_layout(height=430, title_x=0.02, xaxis_title="Median salary USD", yaxis_title="Negara perusahaan")
        fig.update_traces(texttemplate="$%{text:,.0f}", textposition="outside")
        st.plotly_chart(fig, use_container_width=True)

    with right:
        fig = px.bar(
            country_count.head(10).sort_values("total_data"),
            x="total_data",
            y="company_country",
            orientation="h",
            text="total_data",
            title="Negara berdasarkan jumlah data job"
        )
        fig.update_layout(height=430, title_x=0.02, xaxis_title="Jumlah data", yaxis_title="Negara perusahaan")
        fig.update_traces(textposition="outside")
        st.plotly_chart(fig, use_container_width=True)

    da_country_salary = (
        filtered_salary[filtered_salary["role_group"] == "Data Analyst"]
        .groupby("company_country")
        .agg(total_data=("salary_in_usd", "count"), median_salary=("salary_in_usd", "median"))
        .reset_index()
    )

    da_country_salary = da_country_salary[da_country_salary["total_data"] >= 3].sort_values("median_salary", ascending=False)

    if not da_country_salary.empty:
        fig = px.bar(
            da_country_salary.head(10).sort_values("median_salary"),
            x="median_salary",
            y="company_country",
            orientation="h",
            text="median_salary",
            title="Median salary Data Analyst berdasarkan negara perusahaan"
        )
        fig.update_layout(height=450, title_x=0.02, xaxis_title="Median salary USD", yaxis_title="Negara perusahaan")
        fig.update_traces(texttemplate="$%{text:,.0f}", textposition="outside")
        st.plotly_chart(fig, use_container_width=True)

    st.info(
        "Insight utama: United States biasanya dominan dari sisi jumlah data dan kompensasi. "
        "Karena dataset tidak seimbang antarnegara, gunakan filter minimal data agar hasilnya lebih masuk akal."
    )


# ============================================================
# Skill
# ============================================================

with tab_skill:
    st.subheader("Skill yang dicari perusahaan")

    if not load_skill_section:
        st.warning("Aktifkan pilihan 'Muat analisis skill dari Hugging Face' di sidebar untuk melihat bagian ini.")
    else:
        try:
            skill_tables = build_skill_tables()

            skill_overall = skill_tables["skill_overall"]
            skill_data_analyst = skill_tables["skill_data_analyst"]
            skill_role_matrix = skill_tables["skill_role_matrix"]
            skill_remote_top = skill_tables["skill_remote_top"]
            remote_compare = skill_tables["remote_compare"]
            skill_recommendation = skill_tables["skill_recommendation"]
            work_type_summary = skill_tables["work_type_summary"]

            c1, c2, c3 = st.columns(3)
            c1.metric("Job posting dengan skill", f"{skill_tables['total_jobs_with_skills']:,}")
            c2.metric("Data Analyst posting", f"{skill_tables['total_da_jobs']:,}")
            c3.metric("Skill teratas Data Analyst", skill_data_analyst.iloc[0]["skill"].upper(), f"{skill_data_analyst.iloc[0]['percentage']:.2f}%")

            left, right = st.columns(2)

            with left:
                plot_df = skill_overall.head(15).sort_values("total_mentions")
                fig = px.bar(
                    plot_df,
                    x="total_mentions",
                    y="skill",
                    orientation="h",
                    text="total_mentions",
                    title="Top skill paling banyak dicari"
                )
                fig.update_layout(height=500, title_x=0.02, xaxis_title="Jumlah kemunculan", yaxis_title="Skill")
                fig.update_traces(textposition="outside")
                st.plotly_chart(fig, use_container_width=True)

            with right:
                plot_df = skill_data_analyst.head(15).sort_values("total_mentions")
                fig = px.bar(
                    plot_df,
                    x="total_mentions",
                    y="skill",
                    orientation="h",
                    text="percentage",
                    title="Top skill untuk Data Analyst"
                )
                fig.update_layout(height=500, title_x=0.02, xaxis_title="Jumlah kemunculan", yaxis_title="Skill")
                fig.update_traces(texttemplate="%{text:.1f}%", textposition="outside")
                st.plotly_chart(fig, use_container_width=True)

            st.info(
                "Insight utama: Data Analyst paling banyak membutuhkan SQL, Excel, Python, Tableau, dan Power BI. "
                "Skill ini bisa dianggap sebagai fondasi utama sebelum masuk ke skill yang lebih premium."
            )

            st.divider()
            st.subheader("Perbandingan skill antar role")

            fig = px.imshow(
                skill_role_matrix,
                text_auto=".1f",
                aspect="auto",
                title="Persentase skill utama pada setiap role"
            )
            fig.update_layout(height=520, title_x=0.02, xaxis_title="Role", yaxis_title="Skill")
            st.plotly_chart(fig, use_container_width=True)

            st.divider()
            st.subheader("Skill untuk remote job")

            left, right = st.columns(2)

            with left:
                fig = px.bar(
                    skill_remote_top.head(15).sort_values("total_mentions"),
                    x="total_mentions",
                    y="skill",
                    orientation="h",
                    text="percentage",
                    title="Top skill untuk Work From Home"
                )
                fig.update_layout(height=500, title_x=0.02, xaxis_title="Jumlah kemunculan", yaxis_title="Skill")
                fig.update_traces(texttemplate="%{text:.1f}%", textposition="outside")
                st.plotly_chart(fig, use_container_width=True)

            with right:
                compare_long = remote_compare.melt(
                    id_vars="skill",
                    value_vars=["remote_percentage", "non_remote_percentage"],
                    var_name="work_type",
                    value_name="percentage"
                )
                compare_long["work_type"] = compare_long["work_type"].replace({
                    "remote_percentage": "Work From Home",
                    "non_remote_percentage": "On-site / Not Mentioned"
                })
                fig = px.bar(
                    compare_long,
                    x="percentage",
                    y="skill",
                    color="work_type",
                    barmode="group",
                    orientation="h",
                    title="Remote vs non-remote skill"
                )
                fig.update_layout(height=500, title_x=0.02, xaxis_title="Persentase job posting", yaxis_title="Skill", legend_title="Tipe kerja")
                st.plotly_chart(fig, use_container_width=True)

            st.write("Ringkasan tipe kerja pada dataset skill:")
            st.dataframe(work_type_summary, use_container_width=True)

            st.divider()
            st.subheader("Rekomendasi skill Data Analyst")

            recommended_plot_skills = [
                "sql", "excel", "python", "tableau", "power bi", "looker",
                "snowflake", "spark", "hadoop", "gcp", "aws", "azure", "databricks"
            ]

            rec_plot = skill_recommendation[skill_recommendation["skill"].isin(recommended_plot_skills)].copy()
            rec_plot = rec_plot.sort_values("demand_percentage", ascending=True)

            fig = px.bar(
                rec_plot,
                x="demand_percentage",
                y="skill",
                orientation="h",
                text="median_salary",
                title="Skill rekomendasi untuk Data Analyst berdasarkan demand"
            )
            fig.update_layout(height=500, title_x=0.02, xaxis_title="Persentase muncul di job posting Data Analyst", yaxis_title="Skill")
            fig.update_traces(texttemplate="$%{text:,.0f}", textposition="outside")
            st.plotly_chart(fig, use_container_width=True)

            st.dataframe(
                skill_recommendation[[
                    "skill", "learning_priority", "demand_percentage", "median_salary", "total_mentions", "salary_mentions"
                ]].head(35),
                use_container_width=True
            )

            st.success(
                "Rekomendasi: kuasai SQL, Excel, dan Python sebagai dasar. Lanjutkan dengan Tableau atau Power BI. "
                "Untuk menaikkan value, tambahkan cloud, Snowflake, Spark, Databricks, Airflow, atau Kafka."
            )

        except Exception as error:
            st.error("Analisis skill belum bisa dimuat.")
            st.write("Pastikan koneksi internet aktif dan package `datasets` sudah terpasang.")
            st.exception(error)


# ============================================================
# Opportunity score
# ============================================================

with tab_opportunity:
    st.subheader("Opportunity Score")
    st.write(
        "Skor ini menggabungkan tiga hal: jumlah role dalam dataset, median salary, dan peluang fully remote. "
        "Tujuannya bukan membuat ranking mutlak, tetapi membantu membaca role mana yang paling menarik secara praktis."
    )

    role_opportunity = (
        filtered_salary.groupby("role_group")
        .agg(
            total_data=("salary_in_usd", "count"),
            median_salary=("salary_in_usd", "median"),
            fully_remote_jobs=("remote_label", lambda x: (x == "Fully Remote").sum())
        )
        .reset_index()
    )

    min_role_data = st.slider("Minimal jumlah data per role", min_value=1, max_value=30, value=10)
    role_opportunity = role_opportunity[role_opportunity["total_data"] >= min_role_data].copy()

    if role_opportunity.empty:
        st.warning("Tidak ada role yang memenuhi batas minimal data.")
    else:
        role_opportunity["remote_percentage"] = role_opportunity["fully_remote_jobs"] / role_opportunity["total_data"] * 100

        role_opportunity["demand_score"] = role_opportunity["total_data"] / role_opportunity["total_data"].max() * 100
        role_opportunity["salary_score"] = role_opportunity["median_salary"] / role_opportunity["median_salary"].max() * 100
        role_opportunity["remote_score"] = role_opportunity["remote_percentage"] / role_opportunity["remote_percentage"].max() * 100

        role_opportunity["opportunity_score"] = (
            0.4 * role_opportunity["demand_score"]
            + 0.4 * role_opportunity["salary_score"]
            + 0.2 * role_opportunity["remote_score"]
        )

        role_opportunity = role_opportunity.round(2).sort_values("opportunity_score", ascending=False)

        left, right = st.columns(2)

        with left:
            fig = px.bar(
                role_opportunity.sort_values("opportunity_score"),
                x="opportunity_score",
                y="role_group",
                orientation="h",
                text="opportunity_score",
                title="Ranking Opportunity Score"
            )
            fig.update_layout(height=500, title_x=0.02, xaxis_title="Opportunity score", yaxis_title="Role group")
            fig.update_traces(textposition="outside")
            st.plotly_chart(fig, use_container_width=True)

        with right:
            fig = px.scatter(
                role_opportunity,
                x="total_data",
                y="median_salary",
                size="remote_percentage",
                hover_name="role_group",
                text="role_group",
                title="Demand vs salary, ukuran bubble = remote"
            )
            fig.update_layout(height=500, title_x=0.02, xaxis_title="Jumlah data role", yaxis_title="Median salary USD")
            fig.update_traces(textposition="top center")
            st.plotly_chart(fig, use_container_width=True)

        st.dataframe(role_opportunity, use_container_width=True)

        top_role = role_opportunity.iloc[0]
        st.success(
            f"Role dengan skor tertinggi adalah {top_role['role_group']} dengan Opportunity Score {top_role['opportunity_score']:.2f}. "
            f"Median salary-nya {format_usd(top_role['median_salary'])} dan fully remote sekitar {top_role['remote_percentage']:.2f}%."
        )

        st.markdown(
            """
            **Cara membaca hasil:**
            - Role dengan demand tinggi cocok untuk peluang masuk pasar kerja.
            - Role dengan median salary tinggi cocok untuk target karier jangka panjang.
            - Role dengan remote percentage tinggi menarik untuk fleksibilitas kerja.
            - Data Analyst tetap kuat sebagai jalur awal, lalu bisa berkembang ke Data Scientist, Data Engineer, Analytics Engineer, atau Data Architect.
            """
        )
